% CVX: Internal functions and scripts.
%    This directory contains code that is meant for internal use by
%    the CVX system itself. Documentation of the functions in this
%    directory is more sparse and not intended for end users.

% Copyright 2005-2016 CVX Research, Inc. 
% See the file LICENSE.txt for full copyright information.
% The command 'cvx_where' will show where this file is located.
